<div class="footer">

  <div class="footer_link_bar">
    <ul>
      <li>Created 2014 by </li>
      <li><a href="mailto:coreyelliotnagel@gmail.com">Corey Nagel</a></li>
      <li><a href="index.php">Blog</a></li>
      <li><a href="projects.php">Projects</a></li>
      <li><a href="about.php">About Me</a></li>
      <li><a href="contact.php">Hire/Contact Me</a></li>
      <?php if (!$signedIn) {?>
        <li><a href="login.php">Sign In</a></li>
      <?php }?>
    </ul>
  </div>
</div>